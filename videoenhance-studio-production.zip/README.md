# VideoEnhance Studio — Production Vercel Deployment

## Architecture Overview
- **Frontend & Serverless API**: Hosted on Vercel (React 19 + TypeScript + Vite + Tailwind CSS)
- **Real-Time Client Preview**: WebGL2 Bilateral Denoising, Unsharp Mask, and Lanczos Sampling with zero-latency split-screen comparison
- **Validation Gate**: 12-point media validation protocol (FFprobe integrity, codec conformance, frame cadence, audio sync, keyframe decoding)
- **External Worker (Optional)**: Celery + Redis + PyTorch + FFmpeg for 4K Real-ESRGAN and 120 FPS RIFE renders

## Quick Start
1. `npm install`
2. Copy `.env.example` to `.env` and set `GEMINI_API_KEY`
3. `npm run dev` for local development on http://localhost:3000
4. `npm run build` for production build

## Vercel Deployment Guide
1. Push project to your GitHub repository
2. Import project in Vercel Dashboard
3. Framework Preset: **Vite**
4. Root Directory: `.`
5. Configure Environment Variables:
   - `GEMINI_API_KEY` = Your Google AI Studio API key
   - `APP_URL` = https://your-project.vercel.app
6. Click **Deploy**!
